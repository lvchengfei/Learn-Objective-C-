//
//  CC_CustomViewController.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CC_CustomViewController : UIViewController {
    
}

@end
