//
//  CC_RightTableView.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "CC_RightTableView.h"


@implementation CC_RightTableView
 - (id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		contentArr_ = [[NSArray alloc] initWithObjects:@"111",@"222",@"333", nil];
		self.editing = YES;
		self.allowsSelectionDuringEditing = YES;
		self.dataSource = self;
		self.delegate = self;
		//self.dragging = NO;
	}
	return self;
}

-(void)dealloc
{
	[contentArr_ release];
	[super dealloc];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [contentArr_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	cell.textLabel.text = [contentArr_ objectAtIndex:[indexPath row]];
	cell.showsReorderControl  = YES;
    // Configure the cell...
    
    return cell;
}

//
//// Override to support conditional editing of the table view.
//- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    // Return NO if you do not want the specified item to be editable.
//    return YES;
//}


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */


// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}



// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	return UITableViewCellEditingStyleNone;
}

#pragma mark - LongTouch
- (void)longTouch:(id)timer
{
	NSLog(@"longtouch");

	NSSet* touch = [(NSTimer*)timer userInfo];
	CGPoint pt =  [[touch anyObject] locationInView:self.window];

	[longTouchTimer_ invalidate];
	longTouchTimer_= nil;
	moveView_ = [[CC_MoveView alloc] initWithFrame:CGRectMake(pt.x, pt.y, 70, 45)];
	[moveView_ show];
	self.scrollEnabled = NO;
	
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSLog(@"touch Begain" );
	longTouchTimer_ = [NSTimer scheduledTimerWithTimeInterval:1.5f 
                                                   target:self 
                                                 selector:@selector(longTouch:) 
                                                 userInfo:touches 
                                                  repeats:NO];
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSLog(@"touch Move");
	[longTouchTimer_ invalidate];
	longTouchTimer_ = nil;
	CGPoint currentPoint = [[touches anyObject] locationInView:self.window];
	[moveView_ updatePosition:currentPoint];

}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	self.scrollEnabled = YES;
	[moveView_ dismiss];
	NSLog(@"touch end");
	
}


@end
