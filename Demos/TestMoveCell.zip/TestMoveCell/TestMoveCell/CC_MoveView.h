//
//  CC_MoveView.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CC_MoveView : UIView {
    UILabel* label_;
}

- (void)show;
- (void)dismiss;
- (void)updatePosition:(CGPoint)pt;

@end
