//
//  CC_RightTableView.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CC_MoveView.h"

@interface CC_RightTableView : UITableView <UITableViewDelegate,UITableViewDataSource> {
	NSArray*			contentArr_;
	NSTimer*			longTouchTimer_;
	CC_MoveView*		moveView_;
}

@end
