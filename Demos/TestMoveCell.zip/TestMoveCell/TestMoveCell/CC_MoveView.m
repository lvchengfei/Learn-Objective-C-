//
//  CC_MoveView.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "CC_MoveView.h"


@implementation CC_MoveView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
		label_ = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
		label_.text = @"move";
		label_.backgroundColor = [UIColor grayColor];
		//self.backgroundColor = [UIColor blueColor];
		[self addSubview:label_];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)show
{
	[[UIApplication sharedApplication].keyWindow addSubview:self];
}

- (void)dismiss
{
	[self removeFromSuperview];
}

- (void)updatePosition:(CGPoint)pt
{
	CGRect ct  = CGRectZero;
	ct.size    = self.frame.size;
	ct.origin  = pt ;
	self.frame = ct ;
	//[UIView animateWithDuration:0.2 animations:^{self.center=ceter;} completion:nil];
}

- (void)dealloc
{
	[label_ release];
    [super dealloc];
}

@end
