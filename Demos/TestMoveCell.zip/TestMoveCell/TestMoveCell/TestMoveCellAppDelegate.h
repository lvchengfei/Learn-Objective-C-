//
//  TestMoveCellAppDelegate.h
//  TestMoveCell
//
//  Created by lv on 2/27/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestMoveCellViewController;

@interface TestMoveCellAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet TestMoveCellViewController *viewController;

@end
