//
//  CC_LeftTableView.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CC_LeftTableView : UITableView  <UITableViewDelegate,UITableViewDataSource>{
	NSArray*  contentArr_;

}

@end
